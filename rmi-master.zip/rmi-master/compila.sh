#!/bin/bash

echo LEMBRE-SE de alterar o caminho de diretorio para o JAVA HOME na sua maquina!
~/Downloads/jdk/bin/javac Job.java PrintClient.java PrintServer.java PrintServerInterface.java
