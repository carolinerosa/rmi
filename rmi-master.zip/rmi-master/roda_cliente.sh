#!/bin/bash

echo LEMBRE-SE de alterar o caminho de diretorio para o JAVA HOME na sua maquina!
~/Downloads/jdk/bin/java -cp .:. PrintClient
